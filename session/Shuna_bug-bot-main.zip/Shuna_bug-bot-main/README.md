## 𝐒𝐇𝐔𝐍𝐀_𝐁𝐔𝐆-𝐁𝐎𝐓
</p>
<p align="center">
  <a href="https://github.com/Limule3650/Shuna_bug-bot">
    <img alt=Support height="300" src="https://iili.io/dP0sxmg.jpg"> 
    </p>
<h1 align="center">    💋𝐒𝐄𝐗𝐘 𝐊𝐀𝐖𝐀𝐈 𝐒𝐇𝐔𝐍𝐀 𝐁𝐎𝐓😍 
</h1>
<p align="center"> 
  
<p align="center"> A Whatsapp Bot done by limule Solitarus sama
 
  </a>
</p>
<p align="center">
<a href="https://github.com/Limule3650"><img title="Author" src="https://img.shields.io/badge/𝐒𝐇𝐔𝐍𝐀_𝐁𝐔𝐆-𝐁𝐎𝐓-black?style=for-the-badge&logo=github"></a>
<p/>



---  

</p>


   <p align="left">
  <a href="https://github.com/Limule3650/Shuna_bug-bot/fork">
    <img src="https://img.shields.io/github/forks/Limule3650/Shuna_bug-bot?label=Fork&style=social">
  <p align="left"> 
  <a href="https://github.com/Limule3650/Shuna_bug-bot/stargazers">
    <img src="https://img.shields.io/github/stars/Limule3650/Shuna_bug-bot?style=social">
      
  
 

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{Limule3650}/count.svg" alt="Limule3650 :: Visitor's Count" /></p>
<p align="center">
 <a href="https://whatsapp.com/channel/0029Vafhjw0IXnlonRAQMM2l" target="_blank">
    <img alt="whatsapp Channel" src="https://img.shields.io/badge/ Whatsapp Support Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=Blue" />
  </a>
</p>



# DEPLOY METHODS AND SET-UP 


### 1. FORK THIS REPO
<a href='https://github.com/Limule3650/Shuna_bug-bot/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=Blue'/></a>

### 2. SESSION ID
Scan the QR or Get pairing code.
    <br>
<a href='https://shuna-session.onrender.com' target="_blank"><img alt='SCAN QR' src='https://img.shields.io/badge/Scan_qr-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=red&color=red'/></a>


---


#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-blue?style=for-the-badge&logo=heroku&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://dashboard.heroku.com/new?template=https://github.com/Limule3650/Shuna_bug-bot' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-purple?style=for-the-badge&logo=heroku&logoColor=white'/></a>

#### DEPLOY TO CODESPACE

1. If You don't have a account in Codespace. Create a account.
    <br>
<a href='https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fcodespaces' target="_blank"><img alt='Codespaces' src='https://img.shields.io/badge/CREATE-h?color=blue&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=blue&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>


#### DEPLOY TO RAILWAY

1. If You don't have a account in Railway. Create a account.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/CREATE-h?color=red&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=red&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

#### DEPLOY TO MONGENIUS

1. If You don't have a account in Mongenius. Create a account.
    <br>
<a href='https://studio.mogenius.com/user/registration' target="_blank"><img alt='Mongenius' src='https://img.shields.io/badge/CREATE-h?color=red&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=red&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>


#### DEPLOY TO REPLIT

1. If You don't have a account in Replit. Create a account.
    <br>
<a href='https://replit.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-red?style=for-the-badge&logo=replit&logoColor=black'/></a>

2. Now Deploy
    <br>
<a href='https://replit.com/github/Limule3650/Shuna_bug-bot' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=black'/></a>

---
#

<details close>
<summary>RENDER DEPLOY PROCESS</summary>
   
    1: Click "NEW".
    2: Select "Web Service".
    3: Click "Build and deploy from a Git repository".
    4: Now Choose this forked git repo from list.
    5: And JUST CLICK "Connect". 
   </details>


---


<h2 align="center"> Star This Repo If You like SHUNA🌟
</h2>

#### Developer 

<a href="https://github.com/Limule3650"><img src="https://github.com/Limule3650.png" alt="Limule3650"/></a>




## NB: COPY CODE IF YOU WANT BUT DON'T FORGET TO GIVE CREDIT TO ME

